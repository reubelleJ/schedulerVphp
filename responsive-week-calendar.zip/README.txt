A Pen created at CodePen.io. You can find this one at https://codepen.io/javiercf/pen/GviKy.

 So this is a responsive calendar I coded up pretty quickly, thought I'd share, hope you enjoy